from .core import SystemManager

__version__ = "2.0.0"
__author__ = "Rheehose (Rhee Creative)"

__all__ = ["SystemManager"]
